/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog_part3_poe_st10288567;

/**
 * This class represents a task in a project management system.
 * It stores information about the task such as name, number, description, developer details, duration, ID, and status.
 * It also provides methods to check task description validity, create a task ID, print task details, and return task duration.
 * 
 * @author Darsh Somayi
 */

public class Task {
    
    // Member variables to store task details
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    /**
     * Constructor to initialize a new task with the provided details.
     * 
     * @param taskName The name of the task.
     * @param taskNumber The number of the task.
     * @param taskDescription The description of the task.
     * @param developerDetails The details of the developer assigned to the task.
     * @param taskDuration The duration of the task in hours.
     * @param taskStatus The status of the task (e.g., "To Do", "Done", "Doing").
     */
    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
    }

    /**
     * Method to check if the task description is valid.
     * The task description is valid if it is 50 characters or less.
     * 
     * @return true if the task description is valid, false otherwise.
     */
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    /**
     * Method to create a unique task ID.
     * The task ID is generated using the first 2 characters of the task name, task number, and the first 3 characters of the developer's last name.
     * 
     * @return The generated task ID.
     */
    public String createTaskID() {
        String devInitials = developerDetails.split(" ")[1].substring(0, 3).toUpperCase();
        return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + devInitials;
    }

    /**
     * Method to return the details of the task in a formatted string.
     * 
     * @return A string containing the task details.
     */
    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Duration: " + taskDuration + "hrs";
    }

    /**
     * Method to return the duration of the task.
     * 
     * @return The duration of the task in hours.
     */
    public int returnTotalHours() {
        return taskDuration;
    }
}


//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1
