/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog_part3_poe_st10288567;

/**
 * This class handles the login process for an existing user.
 * It verifies the entered username and password against the registered credentials.
 * 
 * @author Darsh Somayi
 */

import javax.swing.JOptionPane;

public class Login {
    
    /**
     * Method to login the user.
     * Prompts the user to enter their username and password, and checks if they match the registered credentials.
     * 
     * @param registeredUsername The username that was registered.
     * @param registeredPassword The password that was registered.
     * @return true if the entered username and password match the registered credentials, false otherwise.
     */
    public boolean loginUser(String registeredUsername, String registeredPassword) {
        // Prompt user for their username and password
        String inputUsername = JOptionPane.showInputDialog(null, "Enter your username:");
        String inputPassword = JOptionPane.showInputDialog(null, "Enter your password:");
        
        // Check if the entered username and password match the registered credentials
        return inputUsername.equals(registeredUsername) && inputPassword.equals(registeredPassword);
    }
}



//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1
