/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog_part3_poe_st10288567;

/**
 * This program allows users to register, login, and manage tasks. 
 * Tasks can be added, searched, displayed, and deleted. 
 * Reports on tasks can also be generated.
 * 
 * @author Darsh Somayi
 */

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Prog_Part3_POE_ST10288567 {

    // ArrayLists to store task details
    private static ArrayList<String> developers = new ArrayList<>();
    private static ArrayList<String> taskNames = new ArrayList<>();
    private static ArrayList<String> taskIDs = new ArrayList<>();
    private static ArrayList<Integer> taskDurations = new ArrayList<>();
    private static ArrayList<String> taskStatuses = new ArrayList<>();

    public static void main(String[] args) {
        // Instantiate Register and Login objects
        Register register = new Register();
        Login login = new Login();

        // Step 1: Register a new user
        register.registerUser();
        
        // Step 2: Login to the account using registered credentials
        boolean loginSuccess = login.loginUser(register.getUsername(), register.getPassword());

        // Step 2a: Display appropriate message based on login success
        if (loginSuccess) {
            JOptionPane.showMessageDialog(null, "Welcome " + register.getFirstName() + " " + register.getLastName() + ", it is great to see you again.");
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
            return; // Exit if login is unsuccessful
        }

        // Initialize an ArrayList to store tasks
        ArrayList<Task> tasks = new ArrayList<>();

        boolean quit = false; // Flag to control the main menu loop
        while (!quit) {
            // Display the main menu and get the user's choice
            String menu = "Please choose an option:\n1) Add tasks\n2) Show report\n3) Display tasks with status 'done'\n4) Display task with longest duration\n5) Search task by name\n6) Search tasks by developer\n7) Delete task by name\n8) Quit";
            String choice = JOptionPane.showInputDialog(null, menu);

            // Handle user's choice
            switch (choice) {
                case "1":
                    addTasks(tasks); // Add tasks
                    break;
                case "2":
                    displayReport(tasks); // Display report
                    break;
                case "3":
                    displayTasksWithStatusDone(); // Display tasks with status 'done'
                    break;
                case "4":
                    displayTaskWithLongestDuration(); // Display task with longest duration
                    break;
                case "5":
                    searchTaskByName(); // Search task by name
                    break;
                case "6":
                    searchTasksByDeveloper(); // Search tasks by developer
                    break;
                case "7":
                    deleteTaskByName(tasks); // Delete task by name
                    break;
                case "8":
                    quit = true; // Quit the program
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again."); // Handle invalid input
            }
        }
    }

    /**
     * Method to add tasks.
     * @param tasks List of tasks.
     */
    private static void addTasks(ArrayList<Task> tasks) {
        // Get the number of tasks to be added
        String numTasksStr = JOptionPane.showInputDialog(null, "Enter the number of tasks:");
        int numTasks = Integer.parseInt(numTasksStr);

        // Loop to add each task
        for (int i = 0; i < numTasks; i++) {
            // Get task details from the user
            String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter task description:");
            String developerDetails = JOptionPane.showInputDialog(null, "Enter developer details:");
            String taskDurationStr = JOptionPane.showInputDialog(null, "Enter task duration (in hours):");
            int taskDuration = Integer.parseInt(taskDurationStr);
            String[] statuses = {"To Do", "Done", "Doing"};
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:", "Task Status", JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);

            // Create a new Task object
            Task task = new Task(taskName, tasks.size(), taskDescription, developerDetails, taskDuration, taskStatus);

            // Validate task description length
            if (task.checkTaskDescription()) {
                // Add task details to respective ArrayLists
                tasks.add(task);
                developers.add(developerDetails);
                taskNames.add(taskName);
                taskIDs.add(task.createTaskID());
                taskDurations.add(taskDuration);
                taskStatuses.add(taskStatus);

                // Inform user that the task was successfully captured and display task details
                JOptionPane.showMessageDialog(null, "Task successfully captured");
                JOptionPane.showMessageDialog(null, task.printTaskDetails());
            } else {
                // Inform user that the task description is too long and retry the current task
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                i--; // Decrement loop counter to retry current task
            }
        }

        // Calculate and display total hours of all tasks
        int totalHours = tasks.stream().mapToInt(Task::returnTotalHours).sum();
        JOptionPane.showMessageDialog(null, "Total hours: " + totalHours);
    }

    /**
     * Method to display a report of all tasks.
     * @param tasks List of tasks.
     */
    private static void displayReport(ArrayList<Task> tasks) {
        StringBuilder report = new StringBuilder();
        for (Task task : tasks) {
            report.append(task.printTaskDetails()).append("\n\n"); // Append task details to report
        }
        JOptionPane.showMessageDialog(null, report.toString()); // Display the report
    }

    /**
     * Method to display tasks with status 'Done'.
     */
    private static void displayTasksWithStatusDone() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < taskStatuses.size(); i++) {
            if (taskStatuses.get(i).equals("Done")) {
                // Append details of tasks with status 'Done' to result
                result.append("Developer: ").append(developers.get(i))
                      .append(", Task Name: ").append(taskNames.get(i))
                      .append(", Task Duration: ").append(taskDurations.get(i))
                      .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString()); // Display the result
    }

    /**
     * Method to display the task with the longest duration.
     */
    private static void displayTaskWithLongestDuration() {
        if (taskDurations.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks available.");
            return;
        }

        // Find the task with the longest duration
        int maxDuration = taskDurations.get(0);
        int maxIndex = 0;
        for (int i = 1; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                maxIndex = i;
            }
        }
        // Display details of the task with the longest duration
        String message = "Developer: " + developers.get(maxIndex) + ", Duration: " + maxDuration;
        JOptionPane.showMessageDialog(null, message);
    }

    /**
     * Method to search and display a task by name.
     */
    private static void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog(null, "Enter task name to search:");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskName)) {
                // Append details of tasks matching the search name to result
                result.append("Task Name: ").append(taskNames.get(i))
                      .append(", Developer: ").append(developers.get(i))
                      .append(", Task Status: ").append(taskStatuses.get(i))
                      .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString()); // Display the result
    }

    /**
     * Method to search and display tasks by developer.
     */
    private static void searchTasksByDeveloper() {
        String developer = JOptionPane.showInputDialog(null, "Enter developer name to search:");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equals(developer)) {
                // Append details of tasks matching the developer to result
                result.append("Task Name: ").append(taskNames.get(i))
                      .append(", Task Status: ").append(taskStatuses.get(i))
                      .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString()); // Display the result
    }

    /**
     * Method to delete a task by name.
     * @param tasks List of tasks.
     */
    private static void deleteTaskByName(ArrayList<Task> tasks) {
        String taskName = JOptionPane.showInputDialog(null, "Enter task name to delete:");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskName)) {
                // Remove task details from respective ArrayLists
                taskNames.remove(i);
                developers.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                tasks.remove(i); // Remove the task from the tasks ArrayList
                JOptionPane.showMessageDialog(null, "Task '" + taskName + "' successfully deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task '" + taskName + "' not found."); // Display message if task not found
    }
}


//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1
