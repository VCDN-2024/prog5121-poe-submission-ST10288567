/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog_part3_poe_st10288567;

/**
 * This class handles the registration process for a new user.
 * It collects and validates user information such as username, password, first name, and last name.
 * If the username and password meet the required criteria, the user is successfully registered.
 * 
 * @author Darsh Somayi
 */

import javax.swing.JOptionPane;

public class Register {

    // Member variables to store user information
    String username;
    private String password;
    private String firstName;
    private String lastName;

    /**
     * Method to register a new user.
     * The user is prompted to enter their username, password, first name, and last name.
     * The username and password are then checked for correctness.
     */
    public void registerUser() {
        boolean isRegistered = false;
        
        // Loop until the user successfully registers
        while (!isRegistered) {
            // Prompt user for their details
            username = JOptionPane.showInputDialog(null, "Enter username:");
            password = JOptionPane.showInputDialog(null, "Enter password:");
            firstName = JOptionPane.showInputDialog(null, "Enter first name:");
            lastName = JOptionPane.showInputDialog(null, "Enter last name:");

            // Check the format of the username and password
            boolean isUsernameCorrect = checkUserName();
            boolean isPasswordCorrect = checkPasswordComplexity();

            // If both username and password are correct
            if (isUsernameCorrect && isPasswordCorrect) {
                isRegistered = true; // Mark the registration as successful
                
                // Ask user if they want to proceed to the sign-in page
                int option = JOptionPane.showConfirmDialog(null, "Correct username and password. Proceed to the sign-in page?", "Success", JOptionPane.YES_NO_OPTION);
                
                // If user chooses no, reset the registration process
                if (option == JOptionPane.NO_OPTION) {
                    isRegistered = false;
                }
            } else {
                // Inform user about the failed registration due to incorrect username or password format
                JOptionPane.showMessageDialog(null, "Registration failed. Please check username and password format.");
            }
        }
    }

    /**
     * Method to check the format of the username.
     * The username must contain an underscore and be no more than 5 characters in length.
     * 
     * @return true if the username format is correct, false otherwise
     */
    boolean checkUserName() {
        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return false;
        }
    }

    /**
     * Method to check the complexity of the password.
     * The password must be at least 8 characters long, contain a capital letter, a number, and a special character.
     * 
     * @return true if the password meets the complexity requirements, false otherwise
     */
    private boolean checkPasswordComplexity() {
        String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        if (password.matches(regex)) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            return false;
        }
    }

    // Getters for username, password, first name, and last name

    /**
     * Getter for username.
     * 
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Getter for password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Getter for first name.
     * 
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Getter for last name.
     * 
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }
}


//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1
