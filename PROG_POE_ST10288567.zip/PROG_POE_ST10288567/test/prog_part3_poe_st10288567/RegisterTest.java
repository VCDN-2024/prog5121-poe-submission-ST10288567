/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog_part3_poe_st10288567;



/**
 *
 * @author Darsh Somayi
 */
public class RegisterTest {
   
    
  
    
    public void testCheckPasswordComplexity() {
        assertTrue(Login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(Login.checkPasswordComplexity("password"));
    }
    
   
    public void testLoginUser() {
        assertTrue(Login.loginUser("correctUsername", "correctPassword"));
        assertFalse(Login.loginUser("incorrectUsername", "incorrectPassword"));
    }

    private void assertFalse(boolean checkUserName) {
        throw new UnsupportedOperationException("False."); 
    }

    private void assertTrue(boolean checkUserName) {
        throw new UnsupportedOperationException("True."); 
    }

    private static class Login {

        private static boolean checkPasswordComplexity(String chsecke99) {
            throw new UnsupportedOperationException("True."); 
        }

        private static boolean loginUser(String correctUsername, String correctPassword) {
            throw new UnsupportedOperationException("False"); 
        }



        public Login() {
        }
    }
}

//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1
