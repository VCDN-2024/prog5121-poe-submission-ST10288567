/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog_part3_poe_st10288567;



import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testCheckTaskDescription() {
        Task task = new Task("TaskName", 1, "A valid task description", "John Doe", 5, "To Do");
        assertTrue(task.checkTaskDescription());

        Task taskWithLongDescription = new Task("TaskName", 2, "A very long task description that exceeds the fifty character limit imposed by the system.", "Jane Doe", 3, "In Progress");
        assertFalse(taskWithLongDescription.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("TaskName", 1, "A task description", "John Doe", 5, "To Do");
        String expectedTaskID = "TA:1:DOE";
        assertEquals(expectedTaskID, task.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("TaskName", 1, "A task description", "John Doe", 5, "To Do");
        String expectedDetails = "Task Status: To Do\n" +
                                 "Developer Details: John Doe\n" +
                                 "Task Number: 1\n" +
                                 "Task Name: TaskName\n" +
                                 "Task Description: A task description\n" +
                                 "Task ID: TA:1:DOE\n" +
                                 "Duration: 5hrs";
        assertEquals(expectedDetails, task.printTaskDetails());
    }

    @Test
    public void testReturnTotalHours() {
        Task task = new Task("TaskName", 1, "A task description", "John Doe", 5, "To Do");
        assertEquals(5, task.returnTotalHours());
    }

    @Test
    public void testDeveloperArrayPopulation() {
        // Populate the array with test data
        ArrayList<String> developers = new ArrayList<>();
        developers.add("Mike Smith");
        developers.add("Edward Harrison");
        developers.add("Samantha Paulson");
        developers.add("Glenda Oberholzer");

        assertEquals("Mike Smith", developers.get(0));
        assertEquals("Edward Harrison", developers.get(1));
        assertEquals("Samantha Paulson", developers.get(2));
        assertEquals("Glenda Oberholzer", developers.get(3));
    }

    @Test
    public void testTaskWithLongestDuration() {
        ArrayList<Integer> taskDurations = new ArrayList<>();
        ArrayList<String> developers = new ArrayList<>();
        taskDurations.add(5);
        taskDurations.add(8);
        taskDurations.add(2);
        taskDurations.add(11);
        developers.add("Mike Smith");
        developers.add("Edward Harrison");
        developers.add("Samantha Paulson");
        developers.add("Glenda Oberholzer");

        int maxDuration = taskDurations.get(0);
        int maxIndex = 0;
        for (int i = 1; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                maxIndex = i;
            }
        }
        assertEquals(11, maxDuration);
        assertEquals("Glenda Oberholzer", developers.get(maxIndex));
    }

    @Test
    public void testSearchTaskByName() {
        ArrayList<String> taskNames = new ArrayList<>();
        ArrayList<String> developers = new ArrayList<>();
        ArrayList<String> taskStatuses = new ArrayList<>();
        taskNames.add("Create Login");
        developers.add("Mike Smith");
        taskStatuses.add("To Do");

        String taskName = "Create Login";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskName)) {
                result.append("Task Name: ").append(taskNames.get(i))
                      .append(", Developer: ").append(developers.get(i))
                      .append(", Task Status: ").append(taskStatuses.get(i))
                      .append("\n");
            }
        }
        assertEquals("Task Name: Create Login, Developer: Mike Smith, Task Status: To Do\n", result.toString());
    }

    @Test
    public void testSearchTasksByDeveloper() {
        ArrayList<String> developers = new ArrayList<>();
        ArrayList<String> taskNames = new ArrayList<>();
        ArrayList<String> taskStatuses = new ArrayList<>();
        developers.add("Samantha Paulson");
        taskNames.add("Create Reports");
        taskStatuses.add("Done");

        String developer = "Samantha Paulson";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equals(developer)) {
                result.append("Task Name: ").append(taskNames.get(i))
                      .append(", Task Status: ").append(taskStatuses.get(i))
                      .append("\n");
            }
        }
        assertEquals("Task Name: Create Reports, Task Status: Done\n", result.toString());
    }

    @Test
    public void testDeleteTaskByName() {
        ArrayList<String> taskNames = new ArrayList<>();
        ArrayList<String> developers = new ArrayList<>();
        ArrayList<String> taskIDs = new ArrayList<>();
        ArrayList<Integer> taskDurations = new ArrayList<>();
        ArrayList<String> taskStatuses = new ArrayList<>();

        taskNames.add("Create Reports");
        developers.add("Samantha Paulson");
        taskIDs.add("CR:3:PAU");
        taskDurations.add(2);
        taskStatuses.add("Done");

        String taskNameToDelete = "Create Reports";
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskNameToDelete)) {
                taskNames.remove(i);
                developers.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                break;
            }
        }

        assertFalse(taskNames.contains("Create Reports"));
        assertFalse(developers.contains("Samantha Paulson"));
    }
}


//Reference For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160786-dt-content-rid-120712113_1/xid-120712113_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160787-dt-content-rid-120712115_1/xid-120712115_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160788-dt-content-rid-120712114_1/xid-120712114_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21160789-dt-content-rid-120712117_1/xid-120712117_1
